#include "common.h"

int main(int ac, char *av[])
{
    int i, n;

    scanf("%d", &n);
    printf("n = %d\n", n);

    unsigned int sum = 0;
    int *a=(int *)malloc(n*sizeof(int));
    for (i = 0; i < n; i++)
        sum += a[i] = i*i;
    printf("sum = %d\n", sum);
    return 0;
}
