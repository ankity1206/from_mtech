/*
 * Input: a positive integer n, provided as the single command line argument.
 *
 * What the program does:

 * Generates n random numbers between 0 and MAX_NUM-1, prints and
 * stores them one by one in an array, and then prints them in the
 * reverse of the order in which they were generated.
 */

#include "common.h"

#define MAX_NUM 101

int main(int ac, char *av[])
{
    unsigned int i = 0, n, *array;

    if (ac != 2)
        ERR_MESG("Usage: bug3 <positive integer>");
    n = atoi(av[1]);
    if (NULL == (array = Malloc(n, unsigned int)))
        ERR_MESG("bug3: out of memory\n");
    srand((int) time(NULL));
    for (i = 0; i < n; i++) {
        array[i] = rand() % MAX_NUM ;
        printf("%d\n", array[i]);
    }
    for (i = n-1; i >= 0; i--)
        printf("%d ", array[i]);
    putchar('\n');
    return 0;
}