/*
 * Input (via stdin): a string of 0s and 1s (not separated by spaces),
 * e.g., 10101011
 *
 * Output: a rearrangment of the input string such that all 0s appear
 * before all 1s
 *
 * Tasks:
 * 1. find and fix the bug in the given program;
 * 2. simplify the program as much as possible.
 */

 // bug1 is found and fixed
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


int main()
{
    int i;
    int countzero=0;
    int countone=0;
    int c;

    while (EOF != (c = getchar()))
    {
        if(c=='0')
            countzero++;
        else if(c=='1')
            countone++;
        else
            break;
    }
    int* ptr;
    ptr=(int *)malloc((countzero+countone)*sizeof(int));
    i=0;
    while(i<countzero+countone)
    {
        if(i<countzero)
            ptr[i]=0;
        else
            ptr[i]=1;
        i++;           //here was the bug. this line was missing and so loop was running forever
    }
    i=0;
    for(i=0;i<(countzero+countone);i++)
        printf("%d", ptr[i]);
}