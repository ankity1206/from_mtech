#include<stdio.h>
#include<string.h>
int main() {
    int str=1;
    printf("Size of the string = %lu", strlen(str)); 
    return 0;
}