#include"common.h"
#include "heap.h"

typedef struct hnode {
    char ch;
    int freq;
    struct hnode *left, *right;
} HNODE;

HNODE createNode(char ch, int freq){
    HNODE n;
    n.ch = ch;
    n.freq = freq;
    n.left = n.right = NULL;
    return n;
}

int cmp(void *arr, int i, int j){
    HNODE *a = (HNODE *)arr;

    // reverse → smaller freq = higher priority
    return a[j].freq - a[i].freq;
}

HNODE* buildHuffman(char chars[], int freq[], int n){
    HEAP h;
    initHeap(&h, sizeof(HNODE), cmp);

    // insert all nodes
    for(int i=0; i<n; i++){
        HNODE node = createNode(chars[i], freq[i]);
        insert(&h, &node);
    }

    while(h.num_used > 1){
        HNODE x, y;

        deleteMax(&h, &x);  // smallest
        deleteMax(&h, &y);  // second smallest

        HNODE *left = (HNODE*)malloc(sizeof(HNODE));
        HNODE *right = (HNODE*)malloc(sizeof(HNODE));

        *left = x;
        *right = y;

        HNODE z;
        z.ch = '$';  // internal node
        z.freq = x.freq + y.freq;
        z.left = left;
        z.right = right;

        insert(&h, &z);
    }

    HNODE *root = (HNODE*)malloc(sizeof(HNODE));
    deleteMax(&h, root);

    return root;
}
void printCodes(HNODE *root, int code[], int top){
    if(root == NULL) return;

    // left = 0
    if(root->left){
        code[top] = 0;
        printCodes(root->left, code, top+1);
    }

    // right = 1
    if(root->right){
        code[top] = 1;
        printCodes(root->right, code, top+1);
    }

    // leaf
    if(root->left == NULL && root->right == NULL){
        printf("%c: ", root->ch);
        for(int i=0; i<top; i++)
            printf("%d", code[i]);
        printf("\n");
    }
}

int main(){
    char chars[] = {'a','b','c','d','e','f'};
    int freq[]  = {5, 9, 12, 13, 16, 45};
    int n = 6;

    HNODE *root = buildHuffman(chars, freq, n);

    int code[100];
    printCodes(root, code, 0);

    return 0;
}
