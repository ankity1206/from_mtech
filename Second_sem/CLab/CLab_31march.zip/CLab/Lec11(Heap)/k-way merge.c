#include"common.h"
#include "heap.h"

typedef struct {
    int value;
    int listIndex;
    int elemIndex;
} HEAPNODE;

int cmp(void *arr, int i, int j){
    HEAPNODE *a = (HEAPNODE*)arr;
    return a[j].value - a[i].value;  // reverse for min-heap
}

void mergeKLists(int k){
    int sizes[k];
    int *lists[k];

    // input
    for(int i=0; i<k; i++){
        scanf("%d", &sizes[i]);
        lists[i] = (int*)malloc(sizes[i] * sizeof(int));
        for(int j=0; j<sizes[i]; j++){
            scanf("%d", &lists[i][j]);
        }
    }

    HEAP h;
    initHeap(&h, sizeof(HEAPNODE), cmp);

    // insert first element of each list
    for(int i=0; i<k; i++){
        if(sizes[i] > 0){
            HEAPNODE node = {lists[i][0], i, 0};
            insert(&h, &node);
        }
    }

    // merge
    while(h.num_used > 0){
        HEAPNODE minNode;
        deleteMax(&h, &minNode);

        printf("%d ", minNode.value);

        int i = minNode.listIndex;
        int j = minNode.elemIndex + 1;

        if(j < sizes[i]){
            HEAPNODE next = {lists[i][j], i, j};
            insert(&h, &next);
        }
    }

    printf("\n");
}

int main(){
    int t;
    scanf("%d", &t);

    while(t--){
        int k;
        scanf("%d", &k);
        mergeKLists(k);
    }

    return 0;
}