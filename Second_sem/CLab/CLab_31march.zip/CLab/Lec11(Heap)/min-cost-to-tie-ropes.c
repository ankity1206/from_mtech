#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

typedef struct {
    int val;
} NODE;

/* Comparator: reverse to simulate MIN-HEAP using your MAX-HEAP */
int cmp(void *arr, int i, int j){
    NODE *a = (NODE*)arr;
    return a[j].val - a[i].val;  // smaller value = higher priority
}

int main(int argc, char *argv[]){

    if(argc < 2){
        printf("Usage: %s <rope_lengths>\n", argv[0]);
        return 1;
    }

    HEAP h;
    initHeap(&h, sizeof(NODE), cmp);

    // insert all ropes into heap
    for(int i=1; i<argc; i++){
        NODE x;
        x.val = atoi(argv[i]);
        insert(&h, &x);
    }

    int totalCost = 0;

    // keep combining two smallest ropes
    while(h.num_used > 1){
        NODE a, b;

        deleteMax(&h, &a);  // smallest
        deleteMax(&h, &b);  // second smallest

        int sum = a.val + b.val;
        totalCost += sum;

        NODE newNode;
        newNode.val = sum;

        insert(&h, &newNode);
    }

    printf("Minimum cost: %d\n", totalCost);

    free_heap(&h);
    return 0;
}