#include "common.h"
#include "heap.h"

#define EPSILON 1e-10

static int heap_compare_int(void *arr, int i1, int i2)
{
    int *a=arr;
    return a[i1]-a[i2];
}

static int heap_compare_double(void *arr, int i1, int i2)
{
    double *a = arr;
    if (fabs(a[i1] - a[i2]) < EPSILON) return 0;
    return (a[i1] < a[i2]) ? -1 : 1;
}

static int heap_compare_str(void *arr, int i1, int i2)
{
    char **a = arr;
    return strcmp(a[i1], a[i2]);
}


int main(int ac, char *av[])
{
    int i, n, *int_array;
    double f, *d_array;
    char **str_array;
    HEAP h1, h2;  /* test both (init_heap + insert) and build_heap */

    if (ac < 2)
        ERR_MESG("Usage: gheap-testing <type> [element1 element2 ... ]");
    switch(av[1][0]) {
    case 'i': /* integer */
        initHeap(&h1, sizeof(int), heap_compare_int);
        if (NULL == (int_array = Malloc(ac-1, int)))
            ERR_MESG("heap-testing: out of memory");

        for (i = 2; i < ac; i++) {
            n = atoi(av[i]);
            insert(&h1, &n);
            int_array[i-1] = n;
        }
        h2.element_size=sizeof(int);
        h2.num_allocated=h2.num_used=ac-2;
        h2.array=int_array;
        h2.comparator=heap_compare_int;
        buildheap(&h2);

        printf("Successive delete_min/maxs from h1:\n");
        int max;
        for (i = 0; i < ac-2; i++) {
            deleteMax(&h1, &max);/* call delete_max */
            printf("%d ", max);
        }
        putchar('\n');

        heapsort(h2.array, ac-2, sizeof(int), heap_compare_int);
        printf("Result of heapsorting h2:\n");
        for (i = 1; i < ac-1; i++){
            printf("%d ", ((int*)h2.array)[i]);
        }
        putchar('\n');
        break;

    case 'f': /*double */
        initHeap(&h1, sizeof(double), heap_compare_double);
        if (NULL == (d_array = Malloc(ac-1, double)))
            ERR_MESG("heap-testing: out of memory");

        for (i = 2; i < ac; i++) {
            f = atof(av[i]);
            insert(&h1, &f);
            d_array[i-1] = f;
        }
        h2.element_size=sizeof(double);
        h2.num_allocated=h2.num_used=ac-2;
        h2.array=d_array;
        h2.comparator=heap_compare_double;
        buildheap(&h2);

        double max1;
        printf("Successive delete_min/maxs from h1:\n");
        for (i = 0; i < ac-2; i++) {
            deleteMax(&h1, &max1);/* call delete_max */
            printf("%.4f ", max1);
        }
        putchar('\n');

        heapsort(h2.array, ac-2, sizeof(double), heap_compare_double);
        printf("Result of heapsorting h2:\n");
        for (i = 1; i < ac-1; i++)
            printf("%.4f ", ((double*)h2.array)[i]);
        putchar('\n');
        break;

    case 's':
        initHeap(&h1, sizeof(double), heap_compare_str);
        if (NULL == (str_array = Malloc(ac-1, char*)))
            ERR_MESG("heap-testing: out of memory");

        for (i = 2; i < ac; i++) {
            //f = atof(av[i]);
            insert(&h1, &(av[i]));
            str_array[i-1] = av[i];
        }
        h2.element_size=sizeof(char*);
        h2.num_allocated=h2.num_used=ac-2;
        h2.array=str_array;
        h2.comparator=heap_compare_str;
        buildheap(&h2);

        char *max2;
        printf("Successive delete_min/maxs from h1:\n");
        for (i = 0; i < ac-2; i++) {
            deleteMax(&h1, &max2);/* call delete_max */
            printf("%s ", max2);
        }
        putchar('\n');

        heapsort(h2.array, ac-2, sizeof(char*), heap_compare_str);
        printf("Result of heapsorting h2:\n");
        for (i = 1; i < ac-1; i++)
            printf("%s ", ((char**)h2.array)[i]);
        putchar('\n');
        break;

    default:
        fprintf(stderr, "Unknown type %s\n", av[1]);
        break;
    }

    free_heap(&h1); free_heap(&h2);
    return 0;
}