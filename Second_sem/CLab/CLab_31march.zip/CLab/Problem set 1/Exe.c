#include<stdio.h>
#include<stdlib.h>
int main(int ac, char **av){
    printf("%d\n", ac);
    float sum=0;
    for(int i=0; i<ac; i++){
        printf("Argument no. %2d: %s\n", i, av[i]);
        sum=sum+atof(av[i]);
    }
    printf("mean=%f\n", sum/(ac-1));
    
}