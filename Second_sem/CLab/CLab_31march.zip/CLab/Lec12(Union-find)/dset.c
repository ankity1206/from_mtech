#include"dset.h"
#include"common.h"

typedef struct dset {
    int n;
    int *parent;
    int *rank;
}DSET;

DSET *dset_create(int n){
    DSET *ds = malloc(sizeof(DSET));
    if(!ds) return NULL;

    ds->n=n;
    ds->parent = (int *)malloc(n*sizeof(int));
    ds->rank = (int *)malloc(n*sizeof(int));
    for(int i=0; i<n; i++){
        ds->parent[i]=i;
        ds->rank[i]=0;
    }
    return ds;
}

int dset_find(DSET *ds, int x){
    if(x>ds->n){

    }
    if(ds->parent[x]==x){
        return x;
    }
    while(ds->parent[x]!=x){
        x=ds->parent[x];
    }
    return x;
}

void dset_union(DSET *ds, int a, int b){
    if(ds->parent[a]==ds->parent[b]){
        return;
    }
    else{
        int a_parent=dset_find(ds, a);
        int b_parent=dset_find(ds, b);
        if(ds->rank[a_parent]<=ds->rank[b_parent]){
            ds->parent[a_parent]=b_parent;
        }
        else{
            ds->parent[b_parent]=a_parent;
        }
    }
}

int dset_same(DSET *ds, int a, int b){
    if(ds->parent[a]==ds->parent[b]){
        return 1;
    }
    else{
        return 0;
    }
}

void dset_destroy(DSET *ds){
    free(ds->parent);
    free(ds->rank);
    free(ds);
}

/*int main(){
    int n=5;
    DSET *ds=dset_create(n);
    dset_union(ds, 1, 2);
    dset_union(ds, 4, 5);
    int a=4, b=5;
    printf("Are %d and %d in same partition(1 if yes, 0 otherwise): %d\n", a, b, dset_same(ds, a, b));
    dset_destroy(ds);
    return 0;   
}*/