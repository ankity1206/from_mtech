#ifndef DSET_H
#define DSET_H

typedef  struct dset DSET;

DSET *dset_create(int n);

int dset_find(DSET *ds, int x);

void dset_union(DSET *ds, int a, int b);

int dset_same(DSET *ds, int a, int b);

void dset_destroy(DSET *ds);

#endif