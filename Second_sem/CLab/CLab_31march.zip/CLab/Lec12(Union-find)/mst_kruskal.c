#include"common.h"
#include"dset.h"

typedef struct {
    int u;
    int v;
    float weight;
}EDGE;

typedef struct {
    int nVertex;
    int nEdge;
    EDGE *edges;
}GRAPH;

typedef float (*cmpfunc)(void*, int, int);

float cmp( void *A, int i, int j){
	return ((((EDGE *)A + i)->weight) - (((EDGE *)A+j)->weight));
   
}
void gSwap(void *A, void *B, int size){
    char *buffer;
    buffer = (char *)malloc(size);
    assert(buffer != NULL);

    memcpy(buffer, A, size);
    memcpy(A, B, size);
    memcpy(B, buffer, size);
    free(buffer);
}

void bubbleSort(void *A, int arraySize, int elemSize, cmpfunc cf){

	int i,j;

	for(i=0; i< arraySize - 1; i++ ){
		for(j = i+1 ; j < arraySize; j++){
		       if(cf(A,i,j) > 0)
		          gSwap((char *)A + i * elemSize, (char *)A + j * elemSize, elemSize);
		}
	}
}

GRAPH *kruskal(GRAPH *g){
    GRAPH *g_new=(GRAPH*)malloc(sizeof(GRAPH));
    g_new->nEdge=0;
    g_new->nVertex=0;
    g_new->edges=(EDGE*)malloc(sizeof(EDGE));

    bubbleSort((void*)g->edges, g->nEdge, sizeof(EDGE), cmp);
    int j=0;
    DSET *ds=dset_create(g->nVertex);
    for(int i=0; i<g->nEdge; i++){
        if(dset_find(ds,g->edges[i].u)!=dset_find(ds,g->edges[i].v)){
            dset_union(ds, g->edges[i].u, g->edges[i].v);
            g_new->nEdge++;
            if(dset_find(ds, g->edges[i].u)==g->edges[i].u){
                g_new->nVertex++;
            }
            if(dset_find(ds, g->edges[i].v)==g->edges[i].v){
                g_new->nVertex++;
            }
            g_new->edges[j].u=g->edges[i].u;
            g_new->edges[j].v=g->edges[i].v;
            g_new->edges[j].weight=g->edges[i].weight;
            j++;
        }
    }
    /*for(int i=0; i<g->nVertex-1; i++){
        if(dset_find(ds,g->edges[i].u)==dset_find(ds,g->edges[i].v)){
            printf("%d, %d, %f", g->edges[i].u, g->edges[i].v, g->edges[i].weight);
            printf("\n");
        }
    }*/
    return g_new; 
}

int main(){
    GRAPH *g=(GRAPH*)malloc(sizeof(GRAPH));
    
    g->nVertex=4;
    g->nEdge=4;
    EDGE e[]={{1,2,2.5},{2,3,1},{3,4,2},{1,4,1.2}};
    g->edges=e;
    /*for(int i=0; i<g->nEdge; i++){
        printf("%f  ", g->edges[i].weight);
    }
    for(int i=0; i<3; i++){
        g->edges[i].u=i;
        g->edges[i].v=i+1;
    }*/
    g=kruskal(g);
    /*for(int i=0; i<g->nEdge; i++){
        printf("%f  ", g->edges[i].weight);
    }*/
    for(int i=0; i<g->nEdge; i++){
        printf("%d, %d, %f", g->edges[i].u, g->edges[i].v, g->edges[i].weight);
        printf("\n");
    }
    free(g);
    return 0;
}