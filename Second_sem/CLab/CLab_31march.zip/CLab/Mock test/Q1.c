#include"common.h"

int main(){
    int N;
    scanf("%d\n", &N);
    float x[N], y[N];
    char s[N];
    for(int i=0; i<N; i++){
        scanf("%f %f %c\n", &x[i], &y[i], &s[i]);
    }
    float r_x_min, r_x_max, r_y_min, r_y_max, b_x_min, b_x_max, b_y_min, b_y_max; 
    int i=0;
    if(s[i]=='R'){
        r_x_min=r_x_max=x[i];
        r_y_min=r_y_max=y[i];
        i++;
        while(s[i]!='B'&& i<N){
            
            if(x[i]<r_x_min){
                r_x_min=x[i];
            }
            if(x[i]>r_x_max){
                r_x_max=x[i];
            }
            if(y[i]<r_y_min){
                r_y_min=y[i];
            }
            if(y[i]>r_y_max){
                r_y_max=y[i];
            }
            i++;
        }
        if(i<N){
            b_x_max=b_x_min=x[i];
            b_y_max=b_y_min=y[i];
            i++;
        }
        else{
            printf("XY");
            return 0;
        }
    }
    else if(s[i]=='B'){
        b_x_min=b_x_max=x[i];
        b_y_min=b_y_max=y[i];
        i++;
        while(s[i]!='R'&& i<N){
            
            if(x[i]<b_x_min){
                b_x_min=x[i];
            }
            if(x[i]>b_x_max){
                b_x_max=x[i];
            }
            if(y[i]<b_y_min){
                b_y_min=y[i];
            }
            if(y[i]>b_y_max){
                b_y_max=y[i];
            }
            i++;
        }
        if(i<N){
            r_x_max=r_x_min=x[i];
            r_y_max=r_y_min=y[i];
            i++;
        }
        else{
            printf("XY");
            return 0;
        }
    }
    while(i<N){
        if(s[i]=='R'){
            if(x[i]<r_x_min){
                r_x_min=x[i];
            }
            if(x[i]>r_x_max){
                r_x_max=x[i];
            }
            if(y[i]<r_y_min){
                r_y_min=y[i];
            }
            if(y[i]>r_y_max){
                r_y_max=y[i];
            }
        }
        else if(s[i]=='B'){
            if(x[i]<b_x_min){
                b_x_min=x[i];
            }
            if(x[i]>b_x_max){
                b_x_max=x[i];
            }
            if(y[i]<b_y_min){
                b_y_min=y[i];
            }
            if(y[i]>b_y_max){
                b_y_max=y[i];
            }
        }
        i++;
    }
    /*if(((r_x_min<b_x_min)&&(r_x_max<b_x_min)||(b_x_min<r_x_min)&&(b_x_max<r_x_min)) && 
    ((r_y_min<b_y_min)&&(r_y_max<b_y_min)||(b_y_min<r_y_min)&&(b_y_max<r_y_min))){
        printf("XY");
    }*/
    int flag=0;
    if((r_y_min<b_y_min)&&(r_y_max<b_y_min)||(b_y_min<r_y_min)&&(b_y_max<r_y_min)){
        printf("X");
        flag=1;
    }
    if((r_x_min<b_x_min)&&(r_x_max<b_x_min)||(b_x_min<r_x_min)&&(b_x_max<r_x_min)){
        printf("Y");
        flag=1;
    } 
    if(flag==0){
        printf("Not possible");
    }
    return 0;
}