#include"common.h"

int main(){
    char giv_num[1000];
    char c;
    int n=0;
    int freq[10]={0};
    while((c=getchar())!='\n'){
        giv_num[n]=c;
        n++;
    }
    giv_num[n] = '\0';
    //printf("%s\n", giv_num);
    int sum=0;
    //int freq[10];
    for(int i=0; i<n; i++){
        freq[giv_num[i]-'0']++;
        sum+=(giv_num[i]-'0');
    }
    for(int i=0; i<10; i++){
        //printf("%d\n", freq[i]);
    }
    //printf("%d\n", sum);
    char res[1000];
    int j=0;
    int flag=0;
    if(sum%3==0){
        for(int i=9; i>=0; i--){
            while(freq[i]!=0){
                res[j]=i;
                freq[i]--;
                j++;
            }
        }
    }
    else if(sum%3==1){
        for(int i=1; i<8; i+=3){
            if(freq[i]!=0){
                freq[i]--;
                break;
            }
        }
        for(int i=9; i>=0; i--){
            while(freq[i]!=0){
                res[j]=i;
                freq[i]--;
                j++;
            }
        }
    }
    else{
        for(int i=2; i<9; i+=3){
            if(flag==0&&freq[i]!=0){
                freq[i]--;
                flag=1;
            }
        }
        if(flag==0){
            for(int i=1; i<10; i++){
                if(flag==0&&freq[i]!=0){
                    freq[i]--;
                    for(int k=1; k<10; k++){
                        if(flag==0&&(i+k)%3==2 && freq[k]!=0){
                            freq[k]--;
                            flag=1;
                        }
                    }
                }
            }
        }
        for(int i=9; i>=0; i--){
            while(freq[i]!=0){
                res[j]=i;
                freq[i]--;
                j++;
            }
        }
    }
    for(int i=0; i<j; i++){
        printf("%d", res[i]);
    }

}