#include"common.h"

float min_h(float zero, float one, float q){
    if(zero==0||one==0){
        return 0;
    }
    float res;
    if(zero<=one){
        res=-((zero/(zero+one+q))*log2((zero/(zero+one+q)))+((one+q)/(zero+one+q))*log2(((one+q)/(zero+one+q))));
    }
    else{
        res=-((one/(zero+one+q))*log2((one/(zero+one+q)))+((zero+q)/(zero+one+q))*log2(((zero+q)/(zero+one+q))));
    }
    return res;
}
float max_h(float zero, float one, float q){
    float res;
    if(zero==one){
        res=1;
        return res;
    }
    else if(zero<one){
        while(q!=0&&one-zero>0){
            zero++;
            q--;
        }
        while(q>0){
            if(q==1){
                one++;
                q--;
            }    
            else{
                zero++;
                one++;
                q-=2;
            }
            
        }
        
    }
    else{
        while(q!=0&&zero-one>0){
            one++;
            q--;
        }
        while(q>0){
            if(q==1){
                one++;
                q--;
            }    
            else{
                zero++;
                one++;
                q-=2;
            }
            
        }
    }
    if(zero==0||one==0){
        return 0;
    }
    res=-((zero/(zero+one))*log2((zero/(zero+one)))+(one/(zero+one))*log2((one/(zero+one))));
    return res;
}
int main(){
    //char giv_bit[100];
    char c;
    float zero=0, one=0, q=0;
    while((c=getchar())!='\n'){
        if(c=='0'){
            zero++;
        }
        else if(c=='1'){
            one++;
        }
        else{
            q++;
        }
    }
    printf("%.3f %.3f", min_h(zero, one, q), max_h(zero, one, q));
    return 0;

}