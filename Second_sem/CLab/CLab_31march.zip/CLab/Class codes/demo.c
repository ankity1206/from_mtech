#include<stdio.h>

int addOne(int x){
    int a=1;
    printf("Address of a; %p\n", &a);
    return x+a;
}

int main(){
    int y=2;
    int *p;

    int z=addOne(y);

    printf("Address of y: %p\0", &y);
    printf("Address of z: %p", &z);
    return 0;
}