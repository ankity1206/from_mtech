
main(){
    #ifdef ABC
        printf("Hello\n");
    #else 
        printf("world\n");
    #endif
}

