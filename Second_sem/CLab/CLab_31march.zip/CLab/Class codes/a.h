#define N 100 

heyyy
ovhb

bhjh