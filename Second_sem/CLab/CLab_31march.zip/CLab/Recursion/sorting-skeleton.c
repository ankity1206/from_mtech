#include "common.h"

/* ---------- MERGE FUNCTION ---------- */
static void merge(int *a, int *temp, int l, int mid, int r){
    int i = l, j = mid + 1, k = l;

    while(i <= mid && j <= r){
        if(a[i] <= a[j])
            temp[k++] = a[i++];
        else
            temp[k++] = a[j++];
    }

    while(i <= mid)
        temp[k++] = a[i++];

    while(j <= r)
        temp[k++] = a[j++];

    for(i = l; i <= r; i++)
        a[i] = temp[i];
}

/* ---------- MERGESORT ---------- */
static void mergesort_util(int *a, int *temp, int l, int r){
    if(l >= r) return;

    int mid = (l + r) / 2;

    mergesort_util(a, temp, l, mid);
    mergesort_util(a, temp, mid + 1, r);

    merge(a, temp, l, mid, r);
}

void mergesort(int *a, int *temp, uint n){
    mergesort_util(a, temp, 0, n-1);
}

/* ---------- PARTITION (for quicksort) ---------- */
static int partition(int *a, int l, int r){
    int pivot = a[r];  // choose last element
    int i = l - 1;

    for(int j = l; j < r; j++){
        if(a[j] <= pivot){
            i++;
            int t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
    }

    int t = a[i+1];
    a[i+1] = a[r];
    a[r] = t;

    return i+1;
}

/* ---------- QUICKSORT ---------- */
static void quicksort_util(int *a, int l, int r){
    if(l < r){
        int p = partition(a, l, r);

        quicksort_util(a, l, p-1);
        quicksort_util(a, p+1, r);
    }
}

void quicksort(int *a, uint n){
    quicksort_util(a, 0, n-1);
}

/* ---------- MAIN ---------- */
int main(int ac, char *av[])
{
    uint n, i;
    int *array, *temp_array;

    if (ac < 3)
        ERR_MESG("Usage: sorting <-q or -m> n1 n2 n3 ...");

    n = ac - 2;

    if (NULL == (array = Malloc(n, int)) ||
        NULL == (temp_array = Malloc(n, int)))
        ERR_MESG("sorting: out of memory\n");

    for (i = 0; i < n; i++)
        array[i] = atoi(av[i+2]);

    switch(av[1][1]) {   
    case 'm':
        mergesort(array, temp_array, n);
        break;
    case 'q':
        quicksort(array, n);
        break;
    default:
        fprintf(stderr, "Unknown option %s\n", av[1]);
    }

    for (i = 0; i < n; i++)
        printf("%d ", array[i]);

    printf("\n");
    return 0;
}