#include<stdio.h>

float prob_in_board(int m, int n, int i, int j, int k){
    if((i<0 || i>m-1) || (j<0 || j>n-1)){
        return 0;
    }
    if(k==0){
        return 1;
        
    }
    
    float prob=0.0;
    for(int x=i-2; x<=i+2; x+=4){
        for(int y=j-1; y<=j+1; y+=2){
            prob+=prob_in_board(m,n,x,y,k-1);
        }
    }
    for(int x=i-1; x<=i+1; x+=2){
        for(int y=j-2; y<=j+2; y+=4){
            prob+=prob_in_board(m,n,x,y,k-1);
        }
    }
    prob=prob/8;
    return prob;

}

int main(){
    int m,n,i,j,k;
    scanf("%d %d %d %d %d", &m, &n, &i, &j, &k);
    printf("prob= %f", prob_in_board(m,n,i,j,k));
    return 0;
}