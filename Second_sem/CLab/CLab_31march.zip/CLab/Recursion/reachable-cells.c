//Given 1<=n <=5 and 0<=k<=100 find no of reachable cells from any starting cell in an n-dim infinite grid

#include<stdio.h>

int cells(int n, int k){
    if(n==0){
        return 1;
    }
    int count=0;
    for(int i=0; i<=k; i++){
        if(i==0){
            count+=cells(n-1, k);
        }
        else{
            count+=2*cells(n-1, k-i);
        }
    }
    return count;

}

int main(){
    int n, k;
    scanf("%d %d", &n, &k);
    printf("No of reachable cells = %d", cells(n, k));
    return 0;
}