#include<stdio.h>

int G(int n){
    int a=0, b=1, c=2;
    int res;
    if(n<0){
        printf("Please enter positive no");
    }
    if(n==0){
        return a;
    }
    if(n==1){
        return b;
    }
    if(n==2){
        return c;
    }
    for(int i=3; i<=n; i++){
        res=a+b+c;
        a=b;
        b=c;
        c=res;
    }
    return res;
}
int main(){
    int n;
    scanf("%d", &n);
    printf("G(%d)=%d", n, G(n));
    return 0;
}