#include<stdio.h>

void hanoi(int discs, int , int* target){
    
}