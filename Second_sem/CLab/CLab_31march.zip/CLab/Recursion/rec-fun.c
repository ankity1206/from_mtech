#include<stdio.h>

int G(int n){
    if(n==0){
        return 0;
    }
    else if(n==1){
        return 1;
    }
    else if(n==2){
        return 2;
    }
    else{
        return G(n-1)+G(n-2)+G(n-3);
    }
}

int main(){
    int n;
    scanf("%d", &n);
    printf("G(%d)=%d\n", n, G(n));
    return 0;
}