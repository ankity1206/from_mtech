#include<stdio.h>
#include<math.h>

int bin_coef(int n, int r){
    if(r==0||n==r){
        return 1;
    }
    return bin_coef(n-1, r)+bin_coef(n-1, r-1);

}

int main(){
    int n, r;
    scanf("%d", &n);
    scanf("%d", &r);
    int result= bin_coef(n,r);
    printf("%d\n", result);
    return 0;
}