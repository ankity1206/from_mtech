// Given a BST T and an integer n, find the node of T whose value is nearest to n
#include "common.h"
#include"bst-alt.h"

int nearest_node(TREE *tree, int root, int n, int best_val){
    if(root==-1){
        return best_val;
    }
    int cur=tree->nodelist[root].data;
    if(abs(cur-n)<abs(best_val-n) || (abs(cur-n)==abs(best_val-n) && cur<best_val)){
        best_val=cur;
    }
    if(tree->nodelist[root].data > n){
        return nearest_node(tree, tree->nodelist[root].left, n, best_val);
    }
    else if(tree->nodelist[root].data < n){
        return nearest_node(tree, tree->nodelist[root].right, n, best_val);
    }
    else{
        return cur;
    }
}

int main(){
    TREE *tree;
    read_tree(tree);
    int best;
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    best=nearest_node(tree, tree->root, n, tree->nodelist[tree->root].data);
    printf("%d\n", best);
    return 0;
}