#include "common.h"
#include "bst-alt.h"

int stack[100];
int top;
void inorder(TREE *tree, int root){
    if(root==-1){
        return;
    }
    top=-1;
    int cur=root;
    while(cur!=-1 || top!=-1){
        while(cur!=-1){
            stack[++top]=cur;
            cur=tree->nodelist[cur].left;
        }
        cur=stack[top--];
        printf("%d ", tree->nodelist[cur].data);
        cur=tree->nodelist[cur].right;
    }
    return;
}
void preorder(TREE *tree, int root){
    if(root==-1){
        return;
    }
    top=-1;
    int cur=root;
    stack[++top]=cur;
    while(top!=-1){
        cur=stack[top--];
        printf("%d ", tree->nodelist[cur].data);
        if(tree->nodelist[cur].right!=-1)
            stack[++top]=tree->nodelist[cur].right;
        if(tree->nodelist[cur].left!=-1)
            stack[++top]=tree->nodelist[cur].left;
    }
    return;
}
void postorder(TREE *tree, int root){
    if(root==-1){
        return;
    }
    top=-1;
    int last_visited=-1;
    int cur=root;
    int peek;
    while(top!=-1 || cur!=-1){
        if(cur!=-1){
            stack[++top]=cur;
            cur=tree->nodelist[cur].left;
        }
        else{
            peek=stack[top];
            if(tree->nodelist[peek].right!=-1 && tree->nodelist[peek].right!=last_visited){
                cur=tree->nodelist[peek].right;
            }
            else{
                printf("%d ", tree->nodelist[peek].data);
                last_visited=stack[top--];
            }
        }
    }
    return;
}

int main(int ac, char *av[])
{
    int *data, num, i, j;
    NODE *nodeptr;
    TREE tree;

    if (ac != 2)
        ERR_MESG("Usage: bst <number>");
    num = atoi(av[1]); // max. number of nodes

    /* Initialise tree: should move this to a separate init_tree function */
    tree.num_nodes = 0;
    tree.max_nodes = num;
    tree.root = -1;
    tree.free_list = 0;
    /* TODO: set up free_list properly */

    if (NULL == (tree.nodelist = Malloc(num, NODE)) ||
        NULL == (data = Malloc(num, int)))
        ERR_MESG("bst: out of memory");
    for (i = 0; i < num - 1; i++) {
        tree.nodelist[i].left = i + 1;
    }
    tree.nodelist[num - 1].left = -1;
    /* Insert nodes */
    srandom((int) time(NULL)); // Commented for reproducibility
    for (i = 0; i < num; i++) {
        data[i] = random() % 10000;
        tree.root = insert(&tree, tree.root, data[i]);
        fprintf(stderr, "After inserting %d\n", data[i]);
        print_pstree(&tree, tree.root);
        fprintf(stderr, "\n\n");
    }
    printf("Inorder traversal: ");
    inorder(&tree,tree.root);
    printf("\n");
    printf("Preorder traversal: ");
    preorder(&tree,tree.root);
    printf("\n");
    printf("Postorder traversal: ");
    postorder(&tree,tree.root);
    printf("\n");

    /* Dump the tree as a table: should move this to print_tree_as_table() */
    printf("Total nodes: %u\n", tree.num_nodes);
    printf("Tree printed as table:\n");
    for (i = 0, nodeptr = tree.nodelist; i < tree.num_nodes; i++, nodeptr++)
        printf("%d %d %d\n", nodeptr->data,
#ifdef LINENUM
               (nodeptr->left > 0) ? nodeptr->left + 2 : nodeptr->left,
               (nodeptr->right > 0) ? nodeptr->right + 2 : nodeptr->right
#else
               nodeptr->left, nodeptr->right
#endif
            );
    printf("\nTree printed sidewise:");
    print_tree(&tree, tree.root, 0);
    /*Delete nodes */
    for (i = 0; i < num; i++) {
        j = rand() % num;
        if (data[j] != -1) {
            tree.root = delete(&tree, tree.root, data[j]);
            fprintf(stderr, "After deleting %d:\n", data[j]);
            print_pstree(&tree, tree.root);
            fprintf(stderr, "\n\n");
            data[j] = -1;
        }
    }

    return 0;
}