#include "common.h"
#include "gen-bst.h"

static int cmp_int(void *a, int i1, int i2){
    TREE *tree=a;
    return *(int*)(tree->nodelist[i1].data) - *(int*)(tree->nodelist[i2].data);
}
static int cmp_double(void *a, int i1, int i2){
    TREE *tree=a;
    double x = *(double*)(tree->nodelist[i1].data);
    double y = *(double*)(tree->nodelist[i2].data);
    if( fabs(x - y)<1e-10)
        return 0;
    return (x<y) ? -1: 1;
}
static int cmp_str(void *a, int i1, int i2){
    TREE *tree = a;
    char *x = *(char**)(tree->nodelist[i1].data);
    char *y = *(char**)(tree->nodelist[i2].data);
    return strcmp(x, y);
}
int intCmp(void *a, void *b){
    return *(int*)a - *(int*)b;
}
int doubleCmp(void *a, void *b){
    double x = *(double*)a;
    double y = *(double*)b;
    if( fabs(x - y)<1e-10)
        return 0;
    return (x<y) ? -1: 1;
}
int strCmp(void *a, void *b){
    char *x= *(char**)a;
    char *y = *(char**)b;
    return strcmp(x, y);
}


void inorder(TREE *tree, int root) {
    if (root == -1)
        return;
    inorder(tree, tree->nodelist[root].left);
    printf("%d ", *(int*)tree->nodelist[root].data);
    inorder(tree, tree->nodelist[root].right);
    return;
}
void postorder(TREE *tree, int root) {
    if (root == -1)
        return;
    postorder(tree, tree->nodelist[root].left);
    postorder(tree, tree->nodelist[root].right);
    printf("%d ", *(int*)tree->nodelist[root].data);
    return;
}
void preorder(TREE *tree, int root) {
    if (root == -1)
        return;
    printf("%d ", *(int*)tree->nodelist[root].data);
    preorder(tree, tree->nodelist[root].left);
    preorder(tree, tree->nodelist[root].right);
    
    return;
}

int main(int ac, char *av[])
{
    int *data, num, i, j;
    double *data1;
    char **data2;
    NODE *nodeptr;
    TREE tree;

    if (ac < 2)
        ERR_MESG("Usage: bst <data type>[element1, element2, ....]");
    num = ac-2; // max. number of nodes

    

    switch(av[1][0]){
    case 'i':
        init_tree(&tree, num, sizeof(int), cmp_int);
        data = malloc(num * sizeof(int));
        if (data == NULL)
            ERR_MESG("Out of memory");
    /* Insert nodes */
    //srandom((int) time(NULL)); // Commented for reproducibility
        for (i = 0; i < num; i++) {
            data[i] = atoi(av[2+i]);
            tree.root = insert(&tree, tree.root, &data[i], intCmp);
            fprintf(stderr, "After inserting %d\n", data[i]);
            print_pstree(&tree, tree.root);
            fprintf(stderr, "\n\n");
        }
        printf("Inorder traversal: ");
        inorder(&tree,tree.root);
        printf("\n");
        printf("Preorder traversal: ");
        preorder(&tree,tree.root);
        printf("\n");
        printf("Postorder traversal: ");
        postorder(&tree,tree.root);
        printf("\n");

    /* Dump the tree as a table: should move this to print_tree_as_table() */
        printf("Total nodes: %u\n", tree.num_nodes);
        printf("Tree printed as table:\n");
        for (i = 0, nodeptr = tree.nodelist; i < tree.num_nodes; i++, nodeptr++)
            printf("%d %d %d\n", *(int*)nodeptr->data,
    #ifdef LINENUM
                (nodeptr->left > 0) ? nodeptr->left + 2 : nodeptr->left,
                (nodeptr->right > 0) ? nodeptr->right + 2 : nodeptr->right
    #else
                nodeptr->left, nodeptr->right
    #endif
            );
        printf("\nTree printed sidewise:");
        print_tree(&tree, tree.root, 0);
        /*Delete nodes */
        for (i = 0; i < num; i++) {
            j = rand() % num;
            if (data[j] != -1) {
                tree.root = delete(&tree, tree.root, &data[j], intCmp);
                fprintf(stderr, "After deleting %d:\n", data[j]);
                print_pstree(&tree, tree.root);
                fprintf(stderr, "\n\n");
                data[j] = -1;
            }
        }
        break;

    case 'f':
        init_tree(&tree, num, sizeof(double), cmp_double);
        data1 = malloc(num * sizeof(double));
        if (data1 == NULL)
            ERR_MESG("Out of memory");
    /* Insert nodes */
    //srandom((int) time(NULL)); // Commented for reproducibility
        for (i = 0; i < num; i++) {
            data1[i] = atof(av[2+i]);
            tree.root = insert(&tree, tree.root, &data1[i], doubleCmp);
            fprintf(stderr, "After inserting %.4f\n", data1[i]);
            print_pstree(&tree, tree.root);
            fprintf(stderr, "\n\n");
        }
        printf("Inorder traversal: ");
        inorder(&tree,tree.root);
        printf("\n\n");

    /* Dump the tree as a table: should move this to print_tree_as_table() */
        printf("Total nodes: %u\n", tree.num_nodes);
        printf("Tree printed as table:\n");
        for (i = 0, nodeptr = tree.nodelist; i < tree.num_nodes; i++, nodeptr++)
            printf("%.4f %d %d\n", *(double*)nodeptr->data,
    #ifdef LINENUM
                (nodeptr->left > 0) ? nodeptr->left + 2 : nodeptr->left,
                (nodeptr->right > 0) ? nodeptr->right + 2 : nodeptr->right
    #else
                nodeptr->left, nodeptr->right
    #endif
            );
        printf("\nTree printed sidewise:");
        print_tree(&tree, tree.root, 0);
        /*Delete nodes */
        for (i = 0; i < num; i++) {
            j = rand() % num;
            if (data1[j] != -1) {
                tree.root = delete(&tree, tree.root, &data1[j], doubleCmp);
                fprintf(stderr, "After deleting %.4f:\n", data1[j]);
                print_pstree(&tree, tree.root);
                fprintf(stderr, "\n\n");
                data1[j] = -1;
            }
        }
        break;

    case 's':
        init_tree(&tree, num, sizeof(char*), cmp_str);
        data2 = malloc(num * sizeof(char*));
        if (data2 == NULL)
            ERR_MESG("Out of memory");
    /* Insert nodes */
    //srandom((int) time(NULL)); // Commented for reproducibility
        for (i = 0; i < num; i++) {
            data2[i] = av[2+i];
            tree.root = insert(&tree, tree.root, &data2[i], strCmp);
            fprintf(stderr, "After inserting %s\n", data2[i]);
            print_pstree(&tree, tree.root);
            fprintf(stderr, "\n\n");
        }
        printf("Inorder traversal: ");
        //inorder(&tree,tree.root);
        printf("\n\n");

    /* Dump the tree as a table: should move this to print_tree_as_table() */
        printf("Total nodes: %u\n", tree.num_nodes);
        printf("Tree printed as table:\n");
        for (i = 0, nodeptr = tree.nodelist; i < tree.num_nodes; i++, nodeptr++)
            printf("%s %d %d\n", *(char**)nodeptr->data,
    #ifdef LINENUM
                (nodeptr->left > 0) ? nodeptr->left + 2 : nodeptr->left,
                (nodeptr->right > 0) ? nodeptr->right + 2 : nodeptr->right
    #else
                nodeptr->left, nodeptr->right
    #endif
            );
        printf("\nTree printed sidewise:");
        print_tree_str(&tree, tree.root, 0);
        /*Delete nodes */
        for (i = 0; i < num; i++) {
            j = rand() % num;
            if (data2[j] != NULL) {
                tree.root = delete(&tree, tree.root, &data2[j], strCmp);
                fprintf(stderr, "After deleting %s:\n", data2[j]);
                print_pstree(&tree, tree.root);
                fprintf(stderr, "\n\n");
                data2[j] = NULL;
            }
        }
        break;

    default:
        fprintf(stderr, "Unknown type %s\n", av[1]);
        break;
    }
    return 0;
}