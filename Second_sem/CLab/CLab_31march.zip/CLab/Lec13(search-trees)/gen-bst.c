#include "common.h"
#include "gen-bst.h"

void init_tree(TREE *tree, int max_nodes, size_t element_size, int(*comparator)(void*, int, int)){
    tree->element_size = element_size;
    tree->num_nodes=0;
    tree->max_nodes=max_nodes;
    tree->root=-1;
    tree->free_list=0;
    tree->comparator=comparator;

    if (NULL == (tree->nodelist = Malloc(max_nodes, NODE)))
        ERR_MESG("bst: out of memory");
    for (int i = 0; i < max_nodes - 1; i++) {
        tree->nodelist[i].data = malloc(element_size);
        tree->nodelist[i].left = i + 1;
    }
    tree->nodelist[max_nodes-1].data= malloc(element_size);
    tree->nodelist[max_nodes - 1].left = -1;

}

int insert(TREE *tree, int root, void* d, int(*cmp)(void *, void *)){
    int next;

    if (root == -1) {
        if (-1 == (next = get_new_node(tree)))
            ERR_MESG("insert: out of memory");
        memcpy((char*)tree->nodelist[next].data, d, tree->element_size);
        tree->nodelist[next].left = tree->nodelist[next].right = -1;
        return next;
    }

    if (cmp(d, tree->nodelist[root].data)<0)
        tree->nodelist[root].left = insert(tree, tree->nodelist[root].left, d, cmp);
    else if (cmp(d, tree->nodelist[root].data)>0)
        tree->nodelist[root].right = insert(tree, tree->nodelist[root].right, d, cmp);
    return root;
}

int search(TREE *tree, int root, void *d, int(*cmp)(void *, void *)) {
    if (root == -1) return -1;
    if (cmp(d, tree->nodelist[root].data)<0) 
        return search(tree, tree->nodelist[root].left, d, cmp);
    if (cmp(d, tree->nodelist[root].data)>0)
        return search(tree, tree->nodelist[root].right, d, cmp);
    return root;
}

int delete(TREE *tree, int root, void *d, int(*cmp)(void *, void *)) {
    if (root == -1) return -1;
    int s;
    if (cmp(d, tree->nodelist[root].data)<0)
        tree->nodelist[root].left = delete(tree, tree->nodelist[root].left, d, cmp);
    else if (cmp(d, tree->nodelist[root].data)>0)
        tree->nodelist[root].right = delete(tree, tree->nodelist[root].right, d, cmp);
    else {
        /* TODO: complete this part */
        if (tree->nodelist[root].left == -1 &&
            tree->nodelist[root].right==-1) {
            /* Case I: leaf, just delete */
            free_up_node(tree, root);
            return -1;
        }
        /* Case II: only one child */
        if (tree->nodelist[root].left == -1) {
            s = tree->nodelist[root].right;
            free_up_node(tree, root);
            return s;
        }
        if(tree->nodelist[root].right==-1) {
            s = tree->nodelist[root].left;
            free_up_node(tree, root);
            return s;
        }            
        /* Case III: both sub-trees present */
        s = detach_successor(tree, root);
        tree->nodelist[root].data = tree->nodelist[s].data;
        free_up_node(tree, s);
        return root;
    }

    return root;
}
