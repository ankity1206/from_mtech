//print data elements common to the two given BSTs
#include "common.h"
#include "bst-alt.h"

void common(TREE *t1, TREE *t2){
    int s1[t1->num_nodes], s2[t2->num_nodes];
    int top1=-1, top2=-1, cur1=t1->root, cur2=t2->root;
    while((cur1!=-1||top1!=-1)&&(cur2!=-1||top2!=-1)){
        while(cur1!=-1){
            s1[++top1]=cur1;
            cur1=t1->nodelist[cur1].left;
        }
        while(cur2!=-1){
            s2[++top2]=cur2;
            cur2=t2->nodelist[cur2].left;
        }
        if(top1==-1||top2==-1){
            break;
        }   
        printf("top1=%d top2=%d\n", top1, top2);
        if(t1->nodelist[s1[top1]].data==t2->nodelist[s2[top2]].data){
            
            cur1=s1[top1--];
            cur2=s2[top2--];
            printf("%d ", t1->nodelist[cur1].data);
            cur1=t1->nodelist[cur1].right;
            cur2=t2->nodelist[cur2].right;
        }
        else if(t1->nodelist[s1[top1]].data < t2->nodelist[s2[top2]].data){
            cur1=s1[top1--];
            cur1=t1->nodelist[cur1].right;
        }
        else{
            cur2=s2[top2--];
            cur2=t2->nodelist[cur2].right;
        }
    }
    return;

}
int main(){
    TREE *t1, *t2;
    read_tree(t1);
    read_tree(t2);
    common(t1, t2);
    return 0;
}