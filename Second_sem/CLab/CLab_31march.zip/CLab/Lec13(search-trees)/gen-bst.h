#ifndef BST_ALT_H
#define BST_ALT_H

#include "common.h"
//typedef int DATA;

typedef struct node {
    void* data;  
    int left, right;
} NODE;

typedef struct {
    unsigned int num_nodes, max_nodes;
    size_t element_size;
    int root, free_list; 
    int (*comparator)(void *, int, int);            
    NODE *nodelist;
} TREE;

/* Main operations: see bst-alt.c for what each function returns */
extern void init_tree(TREE *, int max_nodes,  size_t element_size, int(*comparator)(void*, int, int));
extern int insert(TREE *, int root, void *d, int(*cmp)(void *, void *));
extern int search(TREE *, int root, void *d, int(*cmp)(void *, void *));
extern int delete(TREE *, int root, void *d, int(*cmp)(void *, void *));

/* Auxiliary operations (defined in bst-alt-utils.c) */
extern int compare(NODE *n, void *d);
extern int get_new_node(TREE *);
extern void free_up_node(TREE *, int node);
extern int detach_successor(TREE *, int node);

extern void print_tree(TREE*, int root, int indent);
extern void print_tree_str(TREE *tree, int root, int indent);
extern void print_pstree(TREE*, int root);

#endif /* BST_ALT_H */
