#include "common.h"
#include "bst-alt.h"

int insert(TREE *tree, int root, DATA d) {
    int next;

    if (root == -1) {
        if (-1 == (next = get_new_node(tree)))
            ERR_MESG("insert: out of memory");
        tree->nodelist[next].data = d;
        tree->nodelist[next].left = tree->nodelist[next].right = -1;
        return next;
    }

    if (d < tree->nodelist[root].data)
        tree->nodelist[root].left = insert(tree, tree->nodelist[root].left, d);
    else if (d > tree->nodelist[root].data)
        tree->nodelist[root].right = insert(tree, tree->nodelist[root].right, d);
    return root;
}

int search(TREE *tree, int root, DATA d) {
    if (root == -1) return -1;
    if (d < tree->nodelist[root].data) 
        return search(tree, tree->nodelist[root].left, d);
    if (d > tree->nodelist[root].data)
        return search(tree, tree->nodelist[root].right, d);
    return root;
}

int delete(TREE *tree, int root, DATA d) {
    if (root == -1) return -1;
    int s;
    if (d < tree->nodelist[root].data)
        tree->nodelist[root].left = delete(tree, tree->nodelist[root].left, d);
    else if (d > tree->nodelist[root].data)
        tree->nodelist[root].right = delete(tree, tree->nodelist[root].right, d);
    else {
        /* TODO: complete this part */
        if (tree->nodelist[root].left == -1 &&
            tree->nodelist[root].right==-1) {
            /* Case I: leaf, just delete */
            free_up_node(tree, root);
            return -1;
        }
        /* Case II: only one child */
        if (tree->nodelist[root].left == -1) {
            s = tree->nodelist[root].right;
            free_up_node(tree, root);
            return s;
        }
        if(tree->nodelist[root].right==-1) {
            s = tree->nodelist[root].left;
            free_up_node(tree, root);
            return s;
        }            
        /* Case III: both sub-trees present */
        s = detach_successor(tree, root);
        tree->nodelist[root].data = tree->nodelist[s].data;
        free_up_node(tree, s);
        return root;
    }

    return root;
}
