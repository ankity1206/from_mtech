#include<stdio.h>

int main(int ac, char **av){
    printf("%d\n", ac);
    for(int i=0; i<ac; i++){
        printf("Argument no. %2d: %s\n", i, av[i]);
    }
}