#include <stdio.h>
#include <stdlib.h>

typedef int DATA;

typedef struct tnode {
    DATA data;
    int left, right;
    int parent;
} TNODE;

typedef struct {
    int capacity, num_nodes;
    int root;
    TNODE *nodelist;
} TREE;

int read_tree(TREE *t){
    scanf("%d", &t->num_nodes);
    t->capacity = t->num_nodes;
    t->root = 0;

    t->nodelist = (TNODE*)malloc(t->num_nodes * sizeof(TNODE));

    for(int i=0;i<t->num_nodes;i++)
        t->nodelist[i].parent = -1;

    for(int i=0;i<t->num_nodes;i++){
        scanf("%d %d %d",
              &t->nodelist[i].data,
              &t->nodelist[i].left,
              &t->nodelist[i].right);

        int l = t->nodelist[i].left;
        int r = t->nodelist[i].right;

        if(l != -1) t->nodelist[l].parent = i;
        if(r != -1) t->nodelist[r].parent = i;
    }
    return 0;
}

int maxSum = -1000000000;
int leaf1 = -1, leaf2 = -1;

// returns max root-to-leaf sum
int solve(TREE *t, int root, int *leafIndex){

    if(root == -1) return -1000000000;

    TNODE node = t->nodelist[root];

    // leaf node
    if(node.left == -1 && node.right == -1){
        *leafIndex = root;
        return node.data;
    }

    int lLeaf = -1, rLeaf = -1;

    int left = solve(t, node.left, &lLeaf);
    int right = solve(t, node.right, &rLeaf);

    // if both children exist → valid leaf-to-leaf path
    if(node.left != -1 && node.right != -1){
        int sum = left + right + node.data;

        if(sum > maxSum){
            maxSum = sum;
            leaf1 = lLeaf;
            leaf2 = rLeaf;
        }
    }

    // return best root-to-leaf path
    if(left > right){
        *leafIndex = lLeaf;
        return left + node.data;
    } else {
        *leafIndex = rLeaf;
        return right + node.data;
    }
}

int main(){
    TREE *t = (TREE*)malloc(sizeof(TREE));
    read_tree(t);

    int dummy;
    solve(t, t->root, &dummy);

    if(leaf1 == -1 || leaf2 == -1){
        printf("No valid leaf-to-leaf path\n");
    } else {
        printf("%d %d %d\n", leaf1, leaf2, maxSum);
    }

    return 0;
}