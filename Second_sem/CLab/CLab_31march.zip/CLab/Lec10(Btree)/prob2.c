//find if a path exists with node values summing given target value
#include "common.h"

typedef int DATA;
typedef struct tnode {
    DATA data;
    int left, right;
    int parent; //optional
}TNODE;

typedef struct {
    uint capacity, num_nodes;
    // num_nodes is optional
    int root, free;
    TNODE *nodelist;
}TREE;

int read_tree(TREE *t) {
    int i;
    //TNODE *node;

    scanf("%u", &t->num_nodes);
    t->capacity = t->num_nodes;
    t->free = -1;
    t->root = 0;
    if (NULL == (t->nodelist = (TNODE *) malloc(t->num_nodes * sizeof(TNODE)))) {
        fprintf(stderr, "Out of memory\n");
        return -1;
    }
    int left, right;
    for(i=0; i<t->num_nodes; i++)
        t->nodelist[i].parent=-1;

    for (/*node = t->nodelist, */i = 0; i < t->num_nodes;/* node++,*/ i++){
        scanf("%d %d %d", &(t->nodelist[i].data), &(t->nodelist[i].left), &(t->nodelist[i].right));
        left=t->nodelist[i].left;
        right=t->nodelist[i].right;
        if(left!=-1){
            t->nodelist[left].parent=i;
        }
        if(right!=-1){
            t->nodelist[right].parent=i;
        }
    }
    printf("Reading tree completed\n");
    return 0;
}
void printPath(int path[], int len){
    int i;
    for(i=0; i<len-1; i++)
        printf("%d->", path[i]);
    printf("%d", path[i]);
    printf("\n");
}

void rootToLeaf(TREE *t, int root, int target, int path[], int len){
    if(root == -1) return;

    path[len++] = t->nodelist[root].data;

    if(t->nodelist[root].left == -1 && t->nodelist[root].right == -1){
        if(target == t->nodelist[root].data){
            printPath(path, len);
        }
        return;
    }

    rootToLeaf(t, t->nodelist[root].left, target - t->nodelist[root].data, path, len);
    rootToLeaf(t, t->nodelist[root].right, target - t->nodelist[root].data, path, len);
}

int foundLL = 0;
int leafToLeaf(TREE *t, int root, int target){
    if(root == -1) return 0;

    if(t->nodelist[root].left == -1 && t->nodelist[root].right == -1)
        return t->nodelist[root].data;

    int left = leafToLeaf(t, t->nodelist[root].left, target);
    int right = leafToLeaf(t, t->nodelist[root].right, target);

    if(t->nodelist[root].left && t->nodelist[root].right){
        if(left + right + t->nodelist[root].data == target)
            foundLL = 1;
    }

    return (left > right ? left : right) + t->nodelist[root].data;
}

int foundNN = 0;

// DFS from a node (check all downward paths)
void checkFromNode(TREE *t, int root, int currSum, int target){
    if(root == -1) return;

    currSum += t->nodelist[root].data;

    if(currSum == target){
        foundNN = 1;
        return;
    }

    checkFromNode(t, t->nodelist[root].left, currSum, target);
    checkFromNode(t, t->nodelist[root].right, currSum, target);
}

// Try every node as starting point
void nodeToNode(TREE *t, int root, int target){
    if(root == -1) return;

    checkFromNode(t, root, 0, target);

    nodeToNode(t, t->nodelist[root].left, target);
    nodeToNode(t, t->nodelist[root].right, target);
}

int main(){
    TREE *t = (TREE*)malloc(sizeof(TREE));
    read_tree(t);
    int target;
    printf("Enter target value: ");
    scanf("%d", &target);
    int path[100];
    printf("Root to leaf path(if exists): ");
    rootToLeaf(t, t->root, target, path, 0);
    leafToLeaf(t, t->root, target);
    if(foundLL) printf("\nLeaf-to-leaf path exists\n");
    else printf("Leaf-to-leaf path doesn't exist\n");
    foundNN=0;
    nodeToNode(t, t->root, target);
    if(foundNN) printf("Node-to-node path exists\n");
    else printf("Node-to-node path doesn't exist\n");
    return 0;
}