//find btrees in a given forest and print in preorder and also num of nodes
#include"common.h"

typedef int DATA;
typedef struct tnode {
    DATA data;
    int left, right;
    int parent; //optional
}TNODE;

typedef struct {
    uint capacity, num_nodes;
    // num_nodes is optional
    int root, free;
    TNODE *nodelist;
}TREE;
typedef struct{
    uint capacity, num_nodes;
    int free;
    TNODE *nodelist;
}FOREST;

int read_forest(FOREST *f){
    int i;
    scanf("%u", &f->num_nodes);
    f->capacity=f->num_nodes;
    f->free=-1;
    if(NULL==(f->nodelist=(TNODE*)malloc(f->num_nodes*sizeof(TNODE)))){
        fprintf(stderr, "Out of memory\n");
        return -1;
    }
    int left, right;
    for(i=0; i<f->num_nodes; i++){
        f->nodelist[i].parent=-1;
    }
    for(i=0; i< f->num_nodes; i++){
        scanf("%d %d", &(f->nodelist[i].left), &(f->nodelist[i].right));
        left=f->nodelist[i].left;
        right=f->nodelist[i].right;
        if(left!=-1){
            f->nodelist[left].parent=i;
        }
        if(right!=-1){
            f->nodelist[right].parent=i;
        }
    }
    printf("Reading forest completed\n");
    return 0;
}
void findTree(FOREST *f){
    int roots[f->num_nodes];
    int i=0, j=0; 
    while(i<f->num_nodes){
        if(f->nodelist[i].parent==-1){
            roots[j++]=i;
        }
        i++;
    }
    int root, top, cur, nodes, stack[f->num_nodes];
    for(i=0; i<j; i++){
        root=roots[i];
        nodes=0;
        if(root==-1){
            printf("\n");
            continue;
        }
        top=-1;
        cur=root;
        stack[++top]=cur;
        while(top!=-1){
            cur=stack[top--];
            printf("%d ", cur);
            if(f->nodelist[cur].left==-1||f->nodelist[cur].right==-1){
                nodes++;
            }
            if(f->nodelist[cur].right!=-1)
                stack[++top]=f->nodelist[cur].right;
            if(f->nodelist[cur].left!=-1)
                stack[++top]=f->nodelist[cur].left;
        }
        printf("%d\n", nodes); 
    }
    return;
}

int main(){
    FOREST *f=(FOREST*)malloc(sizeof(FOREST));
    read_forest(f);
    findTree(f);
    return 0;
}