//Least comon ancestor
#include"common.h"

typedef int DATA;
typedef struct tnode {
    DATA data;
    int left, right;
    int parent; //optional
}TNODE;

typedef struct {
    uint capacity, num_nodes;
    // num_nodes is optional
    int root, free;
    TNODE *nodelist;
}TREE;

int read_tree(TREE *t) {
    int i;
    //TNODE *node;

    scanf("%u", &t->num_nodes);
    t->capacity = t->num_nodes;
    t->free = -1;
    t->root = 0;
    if (NULL == (t->nodelist = (TNODE *) malloc(t->num_nodes * sizeof(TNODE)))) {
        fprintf(stderr, "Out of memory\n");
        return -1;
    }
    int left, right;
    for(i=0; i<t->num_nodes; i++)
        t->nodelist[i].parent=-1;

    for (/*node = t->nodelist, */i = 0; i < t->num_nodes;/* node++,*/ i++){
        scanf("%d %d %d", &(t->nodelist[i].data), &(t->nodelist[i].left), &(t->nodelist[i].right));
        left=t->nodelist[i].left;
        right=t->nodelist[i].right;
        if(left!=-1){
            t->nodelist[left].parent=i;
        }
        if(right!=-1){
            t->nodelist[right].parent=i;
        }
    }
    printf("Reading tree completed\n");
    return 0;
}

int lca(TREE *t, int i1, int i2){
    int* visited=(int*)malloc(t->num_nodes*sizeof(int));
    for(int i=0; i<t->num_nodes; i++){
        visited[i]=0;
    }
    while(i1!=-1){
        visited[i1]=1;
        i1=t->nodelist[i1].parent;
    }
    while(i2!=-1){
        if(visited[i2]==1){
            return i2;
        }
        i2=t->nodelist[i2].parent;
    }
    return -1;    
}

int main(){
    TREE *t = (TREE*)malloc(sizeof(TREE));
    read_tree(t);
    int i1, i2;
    printf("Enter index1 and index2: ");
    scanf("%d %d", &i1, &i2);
    int Lca;
    Lca = lca(t, i1, i2);
    printf("The index of LCA is: %d\n", Lca);
    return 0;
}