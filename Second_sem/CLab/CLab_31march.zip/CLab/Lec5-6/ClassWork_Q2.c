#include"common.h"

typedef struct student{
    char name[50];
    char roll[50];
    int marks;
}student;

typedef int (*cmpfunc)(void*, int, int);

int marksCmp( void *A, int i, int j){
    student **arr=(student **)A;
	return arr[i]->marks - arr[j]->marks;
}


int nameCompare( void *A, int i, int j){
	char *s1, *s2;

	s1 = (*(student **)A + i)->name;
	s2 = (*(student **)A + j)->name;
	return(strcmp(s1,s2));
}

int rollCompare( void *A, int i, int j){
	char *s1, *s2;

	s1 = (*(student **)A + i)->roll;
	s2 = (*(student **)A + j)->roll;
	return(strcmp(s1,s2));
}

void gSwap(void *A, void *B, int size){
    void *tmp = *(void **)A;
    *(void **)A = *(void **)B;
    *(void **)B = tmp;
}

void bubbleSort(void *A, int arraySize, int elemSize, cmpfunc cf){

	int i,j;

	for(i=0; i< arraySize - 1; i++ ){
		for(j = i+1 ; j < arraySize; j++){
		       if(cf(A,i,j) > 0)
		          gSwap((char *)A + i * elemSize, (char *)A + j * elemSize, elemSize);
		}
	}
}

int lSearchMarksCmp(void *A, void *B) {
    int key = *(int*)A;
    student *s = *(student **)B;
    return key-s->marks;
}
int lSearchNameCmp(void *A, void *B) {
    char* key = *(char **)A;
    student *s = *(student **)B;
    return strcmp(key, s->name);
}

int lSearch(void *A, void *key, int elemSize, int arraySize,  int(*cmp)(void *, void *)){
	int i;
	char *base;

	base = (char *)A;
	for(i = 0; i < arraySize; i++){
		if( cmp(key, base + i * elemSize) == 0)
			return i;
	}
	return -1;
}

int main(int argc, char** argv){
    student** std_list=(student**)malloc(20*sizeof(student*));
    assert(std_list != NULL);
    char name[50], roll[50];
    int marks, size;
    scanf("%d", &size);
    printf("List size=%d\n", size);
    for(int i=0; i<size; i++){
        std_list[i]=malloc(sizeof(student));
        assert(std_list[i] != NULL); 
        scanf("%s", std_list[i]->name);
        scanf("%s", std_list[i]->roll);
        scanf("%d", &std_list[i]->marks);
        printf("%s %s %d\n", std_list[i]->name, std_list[i]->roll, std_list[i]->marks);
    }
    printf("\n");

    student** copy_std_list = malloc(size*sizeof(student*));
    for(int i=0; i<size; i++){
        copy_std_list[i]=malloc(sizeof(student));
    }
    memcpy(copy_std_list, std_list, size*sizeof(student));

    bubbleSort(std_list, size, sizeof(student*), marksCmp);
    printf("After sorting based on marks:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i]->name, std_list[i]->roll, std_list[i]->marks);
    }
    printf("\n");

    int intkey;
	char *strKey;
	int found;
    

	if(argc != 3) { printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
		exit(0);
	}

	if(strcmp(argv[1],"string") != 0 && strcmp(argv[1],"int") != 0){
		 printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
		 exit(0);
	}

	if(strcmp(argv[1], "string") == 0 ){
		strKey = strdup(argv[2]);
		found = lSearch((void *)copy_std_list, (void *)&strKey, sizeof(student*), size, lSearchNameCmp);
		if(found == -1) printf(" The key %s not found \n", strKey);
		else printf("The key %s found at index %d\n", strKey, found);
	}

	else if(strcmp(argv[1], "int") == 0 ){
		intkey = atoi(argv[2]); /* No checking done to ensure it argv[i] is endeed an integer */
                found = lSearch((void *)copy_std_list, (void *)&intkey, sizeof(student*), size, lSearchMarksCmp); 
	        if( found == -1) printf(" The key %d not found\n", intkey);
	        else printf("The key %d found at index %d\n",intkey, found);
	}
	else{ 
		 printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
    }

}
