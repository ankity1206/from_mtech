#include"common.h"

typedef struct student{
    char name[50];
    char roll[50];
    int marks;
}student;

typedef int (*cmpfunc)(void*, int, int);

int marksCmp( void *A, int i, int j){
	return (((student *)A + i)->marks - ((student *)A+j)->marks);
}


int nameCompare( void *A, int i, int j){
	char *s1, *s2;

	s1 = ((student *)A + i)->name;
	s2 = ((student *)A + j)->name;
	return(strcmp(s1,s2));
}

int rollCompare( void *A, int i, int j){
	char *s1, *s2;

	s1 = ((student *)A + i)->roll;
	s2 = ((student *)A + j)->roll;
	return(strcmp(s1,s2));
}


void gSwap(void *A, void *B, int size){
    char *buffer;
    buffer = (char *)malloc(size);
    assert(buffer != NULL);

    memcpy(buffer, A, size);
    memcpy(A, B, size);
    memcpy(B, buffer, size);
    free(buffer);
}



void bubbleSort(void *A, int arraySize, int elemSize, cmpfunc cf){

	int i,j;

	for(i=0; i< arraySize - 1; i++ ){
		for(j = i+1 ; j < arraySize; j++){
		       if(cf(A,i,j) > 0)
		          gSwap((char *)A + i * elemSize, (char *)A + j * elemSize, elemSize);
		}
	}
}
int lSearchRollCmp(void *A, void *B) {
    char* key = *(char **)A;
    student *s = (student *)B;
    return strcmp(key, s->roll);
}

int lSearchNameCmp(void *A, void *B) {
    char* key = *(char **)A;
    student *s = (student *)B;
    return strcmp(key, s->name);
}

int lSearchMarksCmp(void *A, void *B) {
    int key = *(int *)A;
    student *s = (student *)B;
    return key - s->marks;
}

int cmpMarks(const void *a, const void *b) {
    const student *s1 = a;
    const student *s2 = b;
    return s1->marks - s2->marks;
}
int cmpRoll(const void *a, const void *b){
    const student *s1=a;
    const student *s2=b;
    return strcmp(s1->roll, s2->roll);
}
int cmpName(const void *a, const void *b){
    const student *s1=a;
    const student *s2=b;
    return strcmp(s1->name, s2->name);
}

int bsearchMarks(const void *key, const void *elem){
    int k = *(int *)key;
    const student *s = elem;
    return k - s->marks;
}

int bsearchName(const void *key, const void *elem){
    const char *k = *(const char **)key;
    const student *s = elem;
    return strcmp(k, s->name);
}

int bsearchRoll(const void *key, const void *elem){
    const char *k = *(const char **)key;
    const student *s = elem;
    return strcmp(k, s->roll);
}



int lSearch(void *A, void *key, int elemSize, int arraySize,  int(*cmp)(void *, void *)){
	int i;
	char *base;

	base = (char *)A;
	for(i = 0; i < arraySize; i++){
		if( cmp(key, base + i * elemSize) == 0)
			return i;
	}
	return -1;
}

int main(int argc, char** argv){
    student* std_list=Malloc(20, student);
    char name[50], roll[50];
    int marks, size;
    scanf("%d", &size);
    printf("List size=%d\n", size);
    for(int i=0; i<size; i++){ 
        scanf("%s", name);
        strcpy(std_list[i].name, name);
        scanf("%s", roll);
        strcpy(std_list[i].roll, roll);
        scanf("%d", &marks);
        std_list[i].marks=marks;
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }
    printf("\n");

    student* copy_std_list = Malloc(size, student);
    memcpy(copy_std_list, std_list, size*sizeof(student));
    bubbleSort((void*)std_list, size, sizeof(student), marksCmp);
    printf("After sorting based on marks:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }
    printf("\n");

    bubbleSort((void*)std_list, size, sizeof(student), nameCompare);
    printf("After sorting based on names:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }
    printf("\n");

    bubbleSort((void*)std_list, size, sizeof(student), rollCompare);
    printf("After sorting based on rolls:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }
    printf("\n");

    int intkey;
	char *strKey;
	int found;
    

	if(argc != 3) { printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
		exit(0);
	}

	if(strcmp(argv[1],"string") != 0 && strcmp(argv[1],"int") != 0){
		 printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
		 exit(0);
	}

	if(strcmp(argv[1], "string") == 0 ){
		strKey = strdup(argv[2]);
		found = lSearch((void *)copy_std_list, (void *)&strKey, sizeof(student), size, lSearchNameCmp);
		if(found == -1) printf(" The key %s not found \n", strKey);
		else printf("The key %s found at index %d\n", strKey, found);
	}

	else if(strcmp(argv[1], "int") == 0 ){
		intkey = atoi(argv[2]); /* No checking done to ensure it argv[i] is endeed an integer */
                found = lSearch((void *)copy_std_list, (void *)&intkey, sizeof(student), size, lSearchMarksCmp); 
	        if( found == -1) printf(" The key %d not found\n", intkey);
	        else printf("The key %d found at index %d\n",intkey, found);
	}
	else{ 
		 printf("usage: %s string <string>\n OR \n %s int <int>\n ", argv[0], argv[0]);
    }

    qsort(std_list, size, sizeof(student), cmpMarks);
    printf("\nAfter sorting(quick sort) based on marks:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }

    qsort(std_list, size, sizeof(student), cmpRoll);
    printf("\nAfter sorting(quick sort) based on rolls:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }

    qsort(std_list, size, sizeof(student), cmpName);
    printf("\nAfter sorting(quick sort) based on names:\n");
    for(int i=0; i<size; i++){
        printf("%s %s %d\n", std_list[i].name, std_list[i].roll, std_list[i].marks);
    }

    printf("\n----- Binary Search Results -----\n");

    student *res;

    if(strcmp(argv[1], "int") == 0){
        intkey = atoi(argv[2]);

        // Array must be sorted by marks
        qsort(std_list, size, sizeof(student), cmpMarks);

        res = bsearch(&intkey, std_list, size, sizeof(student), bsearchMarks);

        if(res == NULL)
            printf("Marks %d not found (bsearch)\n", intkey);
        else
            printf("Marks %d found: %s %s %d\n",
                   intkey, res->name, res->roll, res->marks);
    }

    else if(strcmp(argv[1], "string") == 0){
        strKey = argv[2];

        // Search by name
        qsort(std_list, size, sizeof(student), cmpName);
        res = bsearch(&strKey, std_list, size, sizeof(student), bsearchName);

        if(res != NULL)
            printf("Name %s found: %s %s %d\n",
                   strKey, res->name, res->roll, res->marks);
        else{
            // If not found by name, try roll
            qsort(std_list, size, sizeof(student), cmpRoll);
            res = bsearch(&strKey, std_list, size, sizeof(student), bsearchRoll);

            if(res != NULL)
                printf("Roll %s found: %s %s %d\n",
                       strKey, res->name, res->roll, res->marks);
            else
                printf("String key %s not found (name/roll)\n", strKey);
        }
    }

    printf("\n");


}