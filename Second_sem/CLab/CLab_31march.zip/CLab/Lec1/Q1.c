#include<stdio.h>
#include<string.h>

int main(){
    char inputstr[1000]; //="c      programming\nis  not    fun!!";
    //int n=0;
    //char c;
    /*while((c=getchar())!='\n'){
        inputstr[n]=c;
        n++;
    }*/
    //while(){
        //printf("%s", inputstr);
        
    //}
    //printf("%s\n", inputstr);

    int freq[26]={0};
    int asc_val, i=0;
    while(fgets(inputstr, 1000, stdin)!=NULL/*inputstr[i]!='\0'*/){
        for(i=0; inputstr[i]!='\0'; i++){
            asc_val=inputstr[i];
            if(asc_val>='a' && asc_val<='z'){
                freq[asc_val-'a']++;
            }
            else if(asc_val>='A' && asc_val<='Z'){
                freq[asc_val-'A']++;
            }
        }
        
    }
    for(int j=0; j<26; j++){
        if(freq[j]>0){
            printf("%c  %d\n", 'a'+j, freq[j]);
        }
    }
}