#include<stdio.h>

int main(){
    char s[100];
    printf("Enter string of atmost 100 characters: ");
    scanf("%s", s);
    int i=0, j=0, count;
    char res[100];
    printf("%s\n", s);
    while(s[i]!='\0'){
        count=1;
        res[j]=s[i];
        j++;
        while(s[i+1]==s[i]){
            i++;
            count++;
        }
        if(count>1){
            res[j]=count+'0';
            j++;
        }
        i++;
    }
    res[j]='\0';
    printf("%s", res);
}