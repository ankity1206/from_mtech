#include<stdio.h>
#include<math.h>

int main(){
    int n;
    printf("Enter 9-digit integer: ");
    scanf("%d", &n);
    int temp=n,i=2, digit, sum=0;
    for(int j=0; j<9; j++){
        digit=temp%10;
        sum=sum+(digit*i);
        temp/=10;
        i++;
    }
    sum=sum%11;
    n=n*10+(11-sum);
    //printf("%d", sum);
    printf("%010d", n);
}