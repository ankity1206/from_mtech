#include<stdio.h>
#include<math.h>

int main(){
    char s[100];
    printf("Enter the run-length encoded string: ");
    scanf("%s", s);
    int i=0, j=0, k, count, dig[5];
    char res[100];
    char ch;
    //printf("%s\n", s);
    while(s[i]!='\0'){
        /*if((s[i]-'0')<=9 && (s[i]-'0')>=0){
            dig[k]=s[i]-'0';
            k++;
            i++;
            continue;
        }
        if(k>0){
            for(int l=k; l>=0; l--){
                count=count*10+dig[l];
            }
            while(count>0){
                res[j]=s[i-k-1];
                j++;
                count--;
            }
            k=0;
        }*/
        ch=s[i];
        i++;
        count=0;
        k=0;
        while((s[i]-'0')<=9 && (s[i]-'0')>=0){
            dig[k]=s[i]-'0';
            k++;
            i++;
        }
        for(int l=k-1; l>=0; l--){
                count=count*10+dig[l];
        }
        if(count==0){
            res[j]=ch;
            j++;
        }
        while(count>0){
                res[j]=ch;
                j++;
                count--;
        }
        
        
    }
    
    res[j]='\0';
    printf("%s", res);
}