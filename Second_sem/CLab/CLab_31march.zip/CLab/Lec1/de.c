#include <stdio.h>
#include <ctype.h>

int main() {
    char s[100];
    char res[1000];
    
    printf("Enter the run-length encoded string: ");
    scanf("%s", s);

    int i = 0, j = 0;

    while (s[i] != '\0') {
        
        char ch = s[i];   // character
        i++;

        int count = 0;

        // read full number (can be multiple digits)
        while (isdigit(s[i])) {
            count = count * 10 + (s[i] - '0');
            i++;
        }

        // if no number given, assume 1
        if (count == 0)
            count = 1;

        // repeat character count times
        while (count--) {
            res[j++] = ch;
        }
    }

    res[j] = '\0';

    printf("Decoded string: %s\n", res);

    return 0;
}

