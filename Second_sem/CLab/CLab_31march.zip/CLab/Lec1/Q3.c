#include<stdio.h>
#include<string.h>

int main(){
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    int A[n];
    printf("Enter %d numbers with space: ", n);
    for(int i=0; i<n; i++){
        scanf("%d", &A[i]);
    }

    for(int i=0; i<n; i++){
        if(A[i]>=n){
            return 0;
        }
        for(int j=0; j<i; j++){
            if(A[i]==A[j]){
                return 0;
            }
        }
    }
    int result[n];
    for(int i=0; i<n; i++){
        result[A[i]]=i;
    }

    for(int i=0; i<n; i++){
        printf("%d ", result[i]);
    }

    
}