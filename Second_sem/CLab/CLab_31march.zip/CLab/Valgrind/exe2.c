#include<stdio.h>
 int main(){
    int n;
    scanf("%d", &n);
    int data[n];

    for(int i=0; i<2*n; i++){
        data[i]=i;
    }
    return 0;
 }