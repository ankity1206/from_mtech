#include <stdio.h>
#include "generic-linked-list.h"

void print_int(const void *data)
{
    printf("%d", *(int *)data);
}
void print_string(const void *data)
{
    printf("%s", (char *)data);
}

int compare_int(const void *a, const void *b)
{
    int x = *(int *)a;
    int y = *(int *)b;
    return x - y;
}
int compare_string(const void *a, const void *b){
    char *x = *(char **)a;
    char *y = *(char **)b;
    return strcmp(x, y);
}

int main()
{
    LIST list;
    list_init(&list, sizeof(char**), print_int, compare_int);
    int a=2, b=3, c=1;
    //char a[20] = "sam", b[20] = "sourav", c[20] = "parama";

    list_insert_back(&list, &a);
    list_insert_back(&list, &b);
    list_insert_front(&list, &c);

    list_print(&list);

    list_destroy(&list);
    return 0;
}
