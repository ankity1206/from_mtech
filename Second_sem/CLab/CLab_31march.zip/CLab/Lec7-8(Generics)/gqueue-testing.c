#include "common.h"
#include "generic-queue.h"

#define MAX_OPS 2

static void print_int(void *d) {
    printf("%10d\n", *((int *) d));
    return;
}

static void print_double(void *d) {
    printf("%10.4lf\n", *((double *) d));
    return;
}

static void print_string(void *d) {
    printf("%s\n", *((char **) d));
    return;
}


int main(int ac, char *av[])
{
    int i, n = -1234;
    double f = -1234.4321;
    char *str;
    QUEUE s;

    if (ac < 2)
        ERR_MESG("Usage: gqueue-main <type> [element1 element2 ... ]");
    switch(av[1][0]) {
    case 'i': /* integer */
        if (create_queue(&s, sizeof(int), print_int, MAX_OPS))
            return -1;
        assert(-1 == dequeue(&s, (void *) &n));
        
        print_int(&n);
        for (i = 2; i < ac; i++) {
            n = atoi(av[i]);
            if (-1 == enqueue(&s, (void *) &n))
                fprintf(stderr, "enqueue %s failed\n", av[i]);
            print_queue(&s);
        }
        for (i = 0; i < ac-2; i++) {
            if (-1 == dequeue(&s, (void *) &n)){
                fprintf(stderr, "dequeue failed (i = %d)\n", i);
            }
            else{
                printf("Dequeued element:");
                print_int((void *) &n);
            } 
           print_queue(&s);
        }
        break;

    case 'f': /*double */
        if (create_queue(&s, sizeof(double), print_double, MAX_OPS))
            return -1;
        assert(-1 == dequeue(&s, (void *) &f));
        print_double(&f);
        for (i = 2; i < ac; i++) {
            f = atof(av[i]);
            if (-1 == enqueue(&s, (void *) &f))
                fprintf(stderr, "enqueue %s failed\n", av[i]);
            print_queue(&s);
        }
        for (i = 2; i < ac; i++) {
            if (-1 == dequeue(&s, (void *) &f))
                fprintf(stderr, "dequeue failed (i = %d)\n", i);
            else print_double((void *) &f);
            print_queue(&s);
        }
        break;

    case 's': /* string */
        if (create_queue(&s, sizeof(double), print_string, MAX_OPS))
            return -1;
        assert(-1 == dequeue(&s, (void *) &f));
        print_double(&f);
        for (i = 2; i < ac; i++) {
            if (-1 == enqueue(&s, (void *) &(av[i])))
                fprintf(stderr, "enqueue %s failed\n", av[i]);
            print_queue(&s);
        }
        for (i = 2; i < ac; i++) {
            if (-1 == dequeue(&s, (void *) &str))
                fprintf(stderr, "dequeue failed (i = %d)\n", i);
            else print_string((void *) &str);
            print_queue(&s);
        }
        break;

    default:
        fprintf(stderr, "Unknown type %s\n", av[1]);
        break;
    }

    delete_queue(&s);
    return 0;
}
