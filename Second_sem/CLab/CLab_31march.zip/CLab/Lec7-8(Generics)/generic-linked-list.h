#ifndef _GLIST_
#define _GLIST_

#include"common.h"

// Function pointer to print an element 
typedef void (*PRINTER_FN)(const void *);

// Function pointer to compare two elements 
typedef int (*COMPARE_FN)(const void *, const void *);

// Node structure 
typedef struct node {
    void *data;
    struct node *next;
} NODE;

// Linked list structure 
typedef struct {
    NODE *head;
    size_t element_size;
    PRINTER_FN print;
    COMPARE_FN compare;
} LIST;


int  list_init(LIST *list, size_t element_size, PRINTER_FN print, COMPARE_FN compare);

int  list_insert_front(LIST *list, void *element);
int  list_insert_back(LIST *list, void *element);

int  list_delete(LIST *list, void *key);
NODE *list_search(LIST *list, void *key);

void list_print(const LIST *list);
void list_destroy(LIST *list);

#endif
