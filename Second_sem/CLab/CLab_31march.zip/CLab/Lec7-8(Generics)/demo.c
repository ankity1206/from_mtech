#include"generic-stack.h"
#include"common.h"

#define MAX_OPS 4

static void print_int(void *d){
    printf("%8d\n", *((int*)d));
    return;
}
int main(){
    int arr[3]={1,2,3};

    STACK s;
    if(create_stack(&s, sizeof(int), print_int, MAX_OPS)){
        return -1;
    }
    for(int i=0; i<3; i++){
        if(-1==push(&s, (void*) &arr[i])){
            fprintf(stderr, "push %d failed", arr[i]);
        }

    }
    print_stack(&s);

    for(int i=0; i<3; i++){
        if(-1==pop(&s, (void*)&arr[i])){
            fprintf(stderr, "pop failed(i=%d)\n", i);
        }
        else{
            print_int((void*)&arr[i]);
        }
        print_stack(&s);
    }
}