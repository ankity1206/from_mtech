#ifndef _B_H_
#define _B_H_
#include "a.h"
#endif
