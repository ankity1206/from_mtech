#include<stdio.h>
#include "a.h"
#include "b.h"
void main(){
    printf("Hello\n");
}