#include"common.h"
#include "generic-stack.h"
#include<math.h>

/* Print integer */
void print_int(void *data)
{
    printf("%d\n", *(int *)data);
}

/* Move one disk between two poles */
void move_disk(STACK *from, STACK *to, char s, char d)
{
    int top_from, top_to;
    int status_from, status_to;

    status_from = pop(from, &top_from);
    status_to   = pop(to, &top_to);

    if (status_from == -1) {
        push(from, &top_to);
        printf("Move disk %d from %c to %c\n", top_to, d, s);
    }
    else if (status_to == -1) {
        push(to, &top_from);
        printf("Move disk %d from %c to %c\n", top_from, s, d);
    }
    else if (top_from > top_to) {
        push(from, &top_from);
        push(from, &top_to);
        printf("Move disk %d from %c to %c\n", top_to, d, s);
    }
    else {
        push(to, &top_to);
        push(to, &top_from);
        printf("Move disk %d from %c to %c\n", top_from, s, d);
    }
}

void tower_of_hanoi(int n)
{
    STACK src, aux, dest;

    create_stack(&src, sizeof(int), print_int, n);
    create_stack(&aux, sizeof(int), print_int, n);
    create_stack(&dest, sizeof(int), print_int, n);

    char s = 'S', a = 'A', d = 'D';

    /* If even disks, swap destination and auxiliary */
    if (n % 2 == 0) {
        char temp = d;
        d = a;
        a = temp;
    }

    /* Push disks onto source */
    for (int i = n; i >= 1; i--)
        push(&src, &i);
    print_stack(&src);
    int total_moves = pow(2, n) - 1;

    for (int i = 1; i <= total_moves; i++) {

        if (i % 3 == 1)
            move_disk(&src, &dest, s, d);

        else if (i % 3 == 2)
            move_disk(&src, &aux, s, a);

        else
            move_disk(&aux, &dest, a, d);
    }
    print_stack(&aux);
    delete_stack(&src);
    delete_stack(&aux);
    delete_stack(&dest);
}

int main()
{
    int n;

    printf("Enter number of disks: ");
    scanf("%d", &n);

    tower_of_hanoi(n);

    return 0;
}
