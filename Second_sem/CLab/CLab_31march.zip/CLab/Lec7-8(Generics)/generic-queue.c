#include "generic-queue.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int create_queue(QUEUE *q, size_t element_size,PRINTER_FN print_element, uint capacity)
{
    assert(q != NULL);
    assert(element_size > 0);
    assert(capacity > 0);

    q->capacity = capacity;
    q->element_size = element_size;
    q->print_element = print_element;

    q->front = 0;
    q->rear = 0;
    q->size = 0;

    q->elements = malloc(capacity * element_size);
    if (q->elements == NULL){
        fprintf(stderr, "create_queue: out of memory\n");
        return -1;
    }
    return 0;
}

void delete_queue(QUEUE *q)
{
    if (q && q->elements) {
        free(q->elements);
        q->elements = NULL;
    }
}


int enqueue(QUEUE *q, void *eptr)
{
    assert(q != NULL);
    assert(eptr != NULL);

    void *tmp;

    if ((q->rear+1)%q->capacity==q->front) {
        q->capacity = 2*q->capacity + 100;
        if (NULL == (tmp = realloc(q->elements, q->capacity * q->element_size))) {
            free(q->elements);
            fprintf(stderr, "enqueue: out of memory\n");
            return -1;
        }
        q->elements = tmp;
    }
    void *dest = (char *)q->elements +(q->rear * q->element_size);

    memcpy(dest, eptr, q->element_size);

    q->rear = (q->rear + 1) % q->capacity;
    q->size++;

    return 0;
}


int dequeue(QUEUE *q, void *eptr)
{
    assert(q != NULL);
    assert(eptr != NULL);


    if (q->size == 0) {
        fprintf(stderr, "deque: underflow (queue empty)\n");
        return -1;
    }
    void *src = (char *)q->elements +(q->front * q->element_size);

    memcpy(eptr, src, q->element_size);

    q->front = (q->front + 1) % q->capacity;
    q->size--;

    return 0;
}


void print_queue(QUEUE *q)
{

    if (q->size == 0) {
        printf("Queue is empty\n");
        return;
    }
    size_t index=q->front;
    printf("Queue capacity: %lu, front = %lu, rear = %lu\n", q->capacity, q->front, q->rear);
    for (size_t i = 0; i < q->size; i++) {
        void *elem = (char *)q->elements +(index * q->element_size);
        q->print_element(elem);
        index = (index + 1) % q->capacity;
    }
    puts("----------------------------------------------------------------------\n");
    return;
}
