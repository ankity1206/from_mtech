#include"common.h"
#include "generic-linked-list.h"

// Initialize list 
int list_init(LIST *list, size_t element_size, PRINTER_FN print, COMPARE_FN compare)
{
    list->head = NULL;
    list->element_size = element_size;
    list->print = print;
    list->compare = compare;
    return 0;
}

// Insert at front 
int list_insert_front(LIST *list, void *element)
{
    NODE *new_node = malloc(sizeof(NODE));
    if (!new_node) return -1;

    new_node->data = malloc(list->element_size);
    if (!new_node->data) {
        free(new_node);
        return -1;
    }

    memcpy(new_node->data, element, list->element_size);

    new_node->next = list->head;
    list->head = new_node;

    return 0;
}

// Insert at back 
int list_insert_back(LIST *list, void *element)
{
    NODE *new_node = malloc(sizeof(NODE));
    if (!new_node) return -1;

    new_node->data = malloc(list->element_size);
    if (!new_node->data) {
        free(new_node);
        return -1;
    }

    memcpy(new_node->data, element, list->element_size);
    new_node->next = NULL;

    if (list->head == NULL) {
        list->head = new_node;
        return 0;
    }

    NODE *temp = list->head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = new_node;

    return 0;
}

// Search by key
NODE *list_search(LIST *list, void *key)
{
    NODE *temp = list->head;

    while (temp != NULL) {
        if (list->compare(temp->data, key) == 0)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

// Delete by key 
int list_delete(LIST *list, void *key)
{
    NODE *temp = list->head;
    NODE *prev = NULL;

    while (temp != NULL) {
        if (list->compare(temp->data, key) == 0) {

            if (prev == NULL)
                list->head = temp->next;
            else
                prev->next = temp->next;

            free(temp->data);
            free(temp);
            return 0;
        }

        prev = temp;
        temp = temp->next;
    }
    return -1;  
}

void list_print(const LIST *list)
{
    NODE *temp = list->head;

    while (temp != NULL) {
        list->print(temp->data);
        printf("->");
        temp = temp->next;
    }

    printf("NULL\n");
}


// Delete entire list 
void list_destroy(LIST *list)
{
    NODE *temp = list->head;

    while (temp != NULL) {
        NODE *next = temp->next;
        free(temp->data);
        free(temp);
        temp = next;
    }
    list->head = NULL;
}
