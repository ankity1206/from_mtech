#ifndef _GQUEUE_
#define _GQUEUE_

#include "common.h"

typedef void (*PRINTER_FN)(void *);

typedef struct {
    void *elements;
    size_t capacity, front, rear, element_size, size;
    PRINTER_FN print_element;
} QUEUE;

extern int create_queue (QUEUE *s, size_t element_size, PRINTER_FN print_element, uint capacity);
extern void delete_queue(QUEUE *s);
extern int enqueue(QUEUE *s, void *eptr);
extern int dequeue(QUEUE *s, void *eptr);
extern void print_queue(QUEUE *s);

#endif 