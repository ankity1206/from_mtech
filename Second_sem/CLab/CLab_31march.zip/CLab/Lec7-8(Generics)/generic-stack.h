#ifndef _GSTACK_
#define _GSTACK_

#include "common.h"

typedef void (*PRINTER_FN)(void *);

typedef struct {
    void *elements;
    size_t capacity, top, element_size;
    PRINTER_FN print_element;
} STACK;

extern int create_stack (STACK *s, size_t element_size, PRINTER_FN print_element, uint capacity);
extern void delete_stack(STACK *s);
/* extern bool is_empty(const STACK *s); */
extern int push(STACK *s, void *eptr);
extern int pop(STACK *s, void *eptr);
extern void print_stack(STACK *s);

#endif // _GSTACK_